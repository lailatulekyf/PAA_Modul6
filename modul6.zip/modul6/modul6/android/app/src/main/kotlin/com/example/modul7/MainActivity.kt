package com.example.modul7

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
